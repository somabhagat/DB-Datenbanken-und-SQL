use versicherung;

-- (1) F�gen Sie folgende Daten in die Datenbank ein:
-- a) neuer Mitarbeiter:

insert into Mitarbeiter (Personalnummer, Name, Vorname, Geburtsdatum, Telefon, Email, Raum, Ist_Leiter, Abteilung_ID, StIdNr)
values ('40003','Maier','Rainer','05.09.1975','0201/4012182','rainer.maier@unserefirma.de','155','N',8,'23782998286');

-- b) neues Inventar:

insert into tbl_inventar 
values	('K-002-239-000010','Regal',1,'112'), 
		('K-013-008-000011','Schreibtisch',1,'112'),
		('K-013-008-000297','B�rostuhl',5,'153');


-- (2) Aktualisieren Sie Tabellen bzw. Datens�tze wie folgt:

-- (a) Die Versicherungsnehmerin Theresia Schiller (ID = 11) ist zur Versicherungsgesellschaft "Knappschaftshilfe Essen"
-- (ID = 3) gewechselt. Sie ist damit also auch nicht mehr eigener Kunde.
-- Schreiben Sie die Anweisung, mit der die Tabelle 'Versicherungsnehmer' entsprechend aktualisiert wird.

UPDATE Versicherungsnehmer 
	SET Eigener_Kunde = 'N', Versicherungsgesellschaft_ID = 3
WHERE ID = 11;

-- (b) Die Versicherungsnehmer Gustav Friedrichsen (ID = 18) und Petra Ottensen (ID = 9) sind zur 
-- Versicherungsgesellschaft "Hannoversche Gesellschaft" (ID = 4) gewechselt. Sie sind damit also 
-- auch nicht mehr eigener Kunde.
-- Schreiben Sie EINE Anweisung, mit der die Tabelle 'Versicherungsnehmer' entsprechend aktualisiert wird.

UPDATE Versicherungsnehmer 
	SET Eigener_Kunde = 'N', Versicherungsgesellschaft_ID = 4
WHERE ID = 18 OR ID = 9;
