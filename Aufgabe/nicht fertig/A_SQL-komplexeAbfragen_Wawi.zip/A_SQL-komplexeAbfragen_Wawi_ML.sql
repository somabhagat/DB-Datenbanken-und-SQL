use wawi;

-- HINWEIS: L�sen Sie die folgenden Aufgaben mit subselects (nicht mit JOIN)

-- ----------------------------------------------------------------
-- Aufgabe 1
-- ----------------------------------------------------------------
-- Erstellen Sie eine Liste aller Artikel, deren Verkaufspreise unter dem Durchschnitt des 
-- gesamten Artikelbestands (also in der Tabelle artikel, unabh�ngig vom Lager) liegen.

select * from artikel;

select avg(vkpreis) from artikel;

select * from artikel
where vkpreis < (select avg(vkpreis) from artikel)
order by vkpreis desc;								-- order lt. Aufg nicht gefordert

-- ----------------------------------------------------------------
-- Aufgabe 2
-- ----------------------------------------------------------------
-- Lassen Sie die Datens�tze aus der Tabelle artikel anzeigen, von denen in den Bestellungen (bestellpositionen) jeweils weniger als 50 St�ck bestellt wurden.

select * from artikel;
select * from bestellpositionen;


select * from bestellpositionen where menge <50;
select artikel from bestellpositionen where menge <50;

select * from artikel
where artnr IN (select artikel from bestellpositionen where menge <50);

-- ----------------------------------------------------------------
-- Aufgabe 3
-- ----------------------------------------------------------------
-- Erstellen Sie eine Personalliste mit den Mitarbeitern, die Gehalt innerhalb der Gehaltsstufe D 
-- beziehen.

select persnr, nachname, gehalt from personal;
select * from gehaltstufen;

select von from gehaltstufen where stufe = 'D';
select bis from gehaltstufen where stufe = 'D';

select persnr, nachname, gehalt from personal
where	gehalt >= (select von from gehaltstufen where stufe = 'D') AND
		gehalt <= (select bis from gehaltstufen where stufe = 'D');

select persnr, nachname, gehalt from personal
where	gehalt between (select von from gehaltstufen where stufe = 'D') AND
		(select bis from gehaltstufen where stufe = 'D');

-- ----------------------------------------------------------------
-- Aufgabe 4
-- ----------------------------------------------------------------
-- Erstellen Sie eine Liste alle Wareneing�nge von denjenigen Lieferanten, die ein Zahlungsziel von 
-- 14 (Tagen) haben.

select * from lieferanten;
select * from wareneingang;

select * from lieferanten where ziel = 14;
select liefnr from lieferanten where ziel = 14;

select * from wareneingang
where lieferant IN (select liefnr from lieferanten where ziel = 14);

-- HINWEIS: L�sen Sie die folgenden Aufgaben mit GROUP BY

-- ----------------------------------------------------------------
-- Aufgabe 5
-- ----------------------------------------------------------------
/* In diesem Handelsunternehmen k�nnen die gleichen Artikel in unterschiedlichen Lagern gelagert
werden (siehe Tabelle lagerstand). 
Erstellen Sie eine Anweisung, die anzeigt, wieviel Artikel mit welcher Artikelnummer insgesamt
vorhanden sind. z.B.
	artnr		Menge
	1005		134
	1008		  6
	1009		 30
	...

Optionale Zusatzaufgabe: Lassen Sie in der og. Liste zus�tzlich die Artikelbezeichnung anzeigen.
*/

select * from lagerstand;

select artnr from lagerstand
group by artnr;

select 
	artnr 'Artikelnummer',
	sum(menge) 'Summe aller Artikel �ber alle Lager'
from lagerstand
group by artnr;

-- ----------------------------------------------------------------
-- Aufgabe 6
-- ----------------------------------------------------------------
/* In der Tabelle bestellpositionen ist gespeichert, welcher Artikel in welcher Bestellung wie oft
 und zu welchem Preis verkauft wurde.
 Erstellen Sie eine Liste, die die Gesamtpreise jeder Bestellung auflistet z.B.:
 bestnr		Summe
 1000		 296.95
 1001		2448.54
 1002		5620.00
 ...

*/

select * from bestellpositionen

select
	bestnr 'Bestellnummer',
	sum(menge*preis) 'Gesamtsumme der Bestellung'
from bestellpositionen
group by bestnr;

