use sakila;

/*
(1) Erstellen Sie eine Liste die angibt, wieviel Kunden aktiv und wieviel nicht aktiv sind. Geben Sie 
den Spalten aussagekräftige Überschriften.
*/

select * from customer;

select active
from customer
group by active;

select 
	active,
    count(*)
from customer
group by active;


/*(2) Erstellen Sie eine Liste mit der Anzahl der Adressen je District. Dabei sollen nur Districte aufgeführt werden, für 
die mehr als 4 Adressen gespeichert sind. Geben Sie den Spalten aussagekräftige Überschriften.
*/

select * from address order by district;

select 
	district,
    count(*)
from address
group by district
order by count(*) desc;		-- Sortierung zunächst für einen besseren Überblick

select 
	district,
    count(*)
from address
group by district
having count(*) > 4
order by count(*) desc;		-- diese Sortierung war in der Aufgabe nicht gefordert


/*(3) Erstellen Sie eine Liste die anzeigt, wieviel Bezahlvorgänge je Kunden in der Tabelle payment erfasst sind.
Ergänzen Sie diese Liste durch die Summe der einzelnen Bezahlvorgänge (amount) je Kunde. Lassen Sie die Liste
sortieren. Die Kunden mit der geringsten Summe sollen am Anfang der Liste stehen.
Geben Sie den Spalten aussagekräftige Überschriften.
*/
select * from payment;

select
	customer_id
from payment
group by customer_id;

select
	customer_id,
    count(*)
from payment
group by customer_id;

select
	customer_id,
    count(*),
    sum(amount)
from payment
group by customer_id
order by sum(amount) asc;

select
	customer_id 'Kunden-Nr',
    count(*) 'Anzahl Bezahlvorgänge der Kunden-Nr',
    sum(amount) 'Summe aller Bezahlvorgänge'
from payment
group by customer_id
order by sum(amount) asc;



/*(4) Ändern Sie die Liste aus (3) so, dass nur die Datensätze angezeigt werden, bei denen die Summe der Bezahlvorgänge größer oder gleich 95 sind.
Geben Sie den Spalten aussagekräftige Überschriften.*/

select
	customer_id 'Kunden-Nr',
    count(*) 'Anzahl Bezahlvorgänge der Kunden-Nr',
    sum(amount) 'Summe aller Bezahlvorgänge'
from payment
group by customer_id
having sum(amount) >= 95
order by sum(amount) asc;


/*(5) Ergänzen Sie die Liste aus (4) so, dass zu den Kunden-Nr. jeweils der Vor- und Zuname des Kunden angezeigt wird.
Geben Sie den Spalten aussagekräftige Überschriften.
*/

select
	payment.customer_id 'Kunden-Nr',
    first_name 'Vorname', 
    last_name 'Nachname',
    count(*) 'Anzahl Bezahlvorgänge der Kunden-Nr',
    sum(amount) 'Summe aller Bezahlvorgänge'
from payment
	join customer on payment.customer_id = customer.customer_id
-- group by payment.customer_id					-- <-- hier fehlen 2 Gruppierungsschlüssel, das sollte nicht funktionieren
group by payment.customer_id, first_name, last_name		-- die Reihenfolge der Gruppierungsschlüssel ist egal
having sum(amount) >= 95
order by sum(amount) asc;
-- NUR die Felder/ Spalten, die nach dem GROUP BY stehen, können auch in der Spaltenliste nach dem SELECT verwendet werden
