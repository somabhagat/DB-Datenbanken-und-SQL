use reisebuero;

-- ---------------------------------------------------------------------------
-- a) Welche Kunden (alle Attribute) haben für welche Reisen (RNR) bereits den vollen Preis eingezahlt?
-- Entwickeln Sie die Anweisung schrittweise:

-- Schritt 1:
select 
	*
from tbl_kunden k
		join tbl_buchungen b on k.knr = b.knr
        join tbl_zahlungen z on b.buchung_id = z.buchung_id
        join tbl_reisen r on b.rnr = r.rnr;

-- Schritt 2:
select
	b.buchung_id
from tbl_kunden k
		join tbl_buchungen b on k.knr = b.knr
        join tbl_zahlungen z on b.buchung_id = z.buchung_id
        join tbl_reisen r on b.rnr = r.rnr
group by buchung_id;

-- Schritt 3:
select
	b.buchung_id,
    sum(zahlungsBetrag)
from tbl_kunden k
		join tbl_buchungen b on k.knr = b.knr
        join tbl_zahlungen z on b.buchung_id = z.buchung_id
        join tbl_reisen r on b.rnr = r.rnr
group by b.buchung_id;

-- Schritt 4:
select
	b.buchung_id,
    sum(zahlungsBetrag)
from tbl_kunden k
		join tbl_buchungen b on k.knr = b.knr
        join tbl_zahlungen z on b.buchung_id = z.buchung_id
        join tbl_reisen r on b.rnr = r.rnr
group by b.buchung_id
having sum(zahlungsBetrag) = r.reise_preis;		-- reise_preis wird als unbekannt reklamiert

-- Schritt 5:
select
	b.buchung_id,
    k.knr,
    k.kunden_name,
    sum(zahlungsBetrag)
from tbl_kunden k
		join tbl_buchungen b on k.knr = b.knr
        join tbl_zahlungen z on b.buchung_id = z.buchung_id
        join tbl_reisen r on b.rnr = r.rnr
group by b.buchung_id, k.knr, k.kunden_name
having sum(zahlungsBetrag) = r.reise_preis;		-- reise_preis wird als unbekannt reklamiert

-- -------------------------------------
select
	b.buchung_id,
    k.knr,
    k.kunden_name,
    reise_preis
from tbl_kunden k
		join tbl_buchungen b on k.knr = b.knr
        join tbl_reisen r on b.rnr = r.rnr
group by b.buchung_id, k.knr, k.kunden_name, reise_preis
having r.reise_preis = (select sum(zahlungsBetrag) from tbl_zahlungen z where z.buchung_id = b.buchung_id group by z.buchung_id);

-- ---------------------------------------------------------------------------
-- b)	Welche Kunden (alle Attribute) haben für (alle) ihre gebuchten Reisen noch nichts eingezahlt?
-- Entwickeln Sie die Anweisung schrittweise:
-- Schritt 1:
select 
	buchung_id
from tbl_buchungen;

-- Schritt 2:
select 
	buchung_id
from tbl_buchungen
where buchung_id NOT IN (select buchung_id from tbl_zahlungen);

-- Schritt 3:
select 
	tbl_kunden.*,
	buchung_id
from tbl_buchungen join tbl_kunden on tbl_buchungen.knr = tbl_kunden.knr
where buchung_id NOT IN (select buchung_id from tbl_zahlungen);

-- ----------------------------------------
-- andere Variante
select 
		k.*,
        buchung_id
from tbl_buchungen b 
		left join tbl_zahlungen z on b.buchung_id = z.buchung_id
        inner join tbl_kunden k on k.knr = b.knr
where zahlungs_ID is NULL;


-- ---------------------------------------------------------------------------
-- c)	In welche Länder sind Reisen ausgebucht?
select
	b.rnr,
    rz.reiseLand,
    rz.reiseOrt,
    sum(buchung_Anzahl_Personen)
from tbl_buchungen b 
			join tbl_reisen r on b.rnr = r.rnr
            join tbl_reiseZiele rz on r.reiseZiel_id = rz.reiseZiel_id
group by b.rnr, rz.reiseland, rz.reiseOrt
having sum(buchung_Anzahl_Personen) = r.bettenanzahl;		-- bettenanzahl ist hier unbekannt
															-- andere Lösungsvariante mit subselect



-- ---------------------------------------------------------------------------
-- 
use maxversicherung;

select * from mitarbeiter;
select * from v

