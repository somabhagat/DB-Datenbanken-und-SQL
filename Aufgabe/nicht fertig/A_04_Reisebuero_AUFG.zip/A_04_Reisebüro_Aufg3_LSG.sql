
create  database reisebuero;
use reisebuero;

create table tbl_kunden
	(knr int primary key,
	kunden_name char(100),
	kunden_anschrift char(100),
	kunden_telefon char(10));

create table tbl_reiseZiele
	(reiseZiel_ID int primary key,
	reiseLand char(100),
	reiseHotel char(100),
	reiseOrt char(100));

create table tbl_reisen
	(rnr int primary key,
	beginn_datum date,
	ende_datum date,
	reise_preis decimal(8,2),
	bettenAnzahl smallint,
	reiseZiel_ID int,
    foreign key (reiseZiel_ID) references tbl_reiseZiele(reiseZiel_ID));

create table tbl_buchungen
	(buchung_ID int primary key,
	knr int not null,
    foreign key (knr) references tbl_kunden(knr), 
	rnr int not null,
    foreign key (rnr) references tbl_reisen(rnr),
	buchung_datum date,
	buchung_anzahl_personen smallint);

create table tbl_zahlungen
	(zahlungs_ID int primary key,
	zahlungsBetrag decimal(8,2),
	zahlungsDatum date,
	buchung_ID int,
    foreign key (buchung_ID) references tbl_buchungen(buchung_ID));
