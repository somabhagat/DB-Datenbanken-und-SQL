/*
	L�sen Sie folgende Aufgaben auf der Datenbank Warenwirtschaft (WaWi)
*/

use warenwirtschaft;

-- ---------------------------------------------------------------------------
-- Aufgabe 1
-- ---------------------------------------------------------------------------
/*
Alle Artikel in der Warengruppe Geschirr (GE) des Herstellers "Grazer Besteck- und Haushaltswaren GmbH" (1001) wurden im Verkaufspreis um 5% verteuert. 
Formulieren Sie die notwendige Anweisung f�r die Aktualisierung der Datens�tze.
Lassen Sie anschlie�end eine Liste der ver�nderten Datens�tze anzeigen.
*/





-- ---------------------------------------------------------------------------
-- Aufgabe 2
-- ---------------------------------------------------------------------------
/*
In der Tabelle Abteilungen soll die Personalnummer des jeweiligen Leiters bzw. der Leiterin gespeichert werden. Geben Sie den notwendigen Befehl
f�r die Anpassung der Tabellenstruktur an.
*/




-- ---------------------------------------------------------------------------
-- Aufgabe 3
-- ---------------------------------------------------------------------------
/*
Die Hinweise zu den Kunden sollen nicht mehr in der Kunden-Tabelle gespeichert werden. Schreiben Sie den notwendigen Befehl f�r das Entfernen der Spalte.
*/





-- ---------------------------------------------------------------------------
-- Aufgabe 4
-- ---------------------------------------------------------------------------
/*
F�gen Sie der Tabelle Spalten f�r versandrelevante Informationen hinzu. Es sollen L�nge, Breite, H�he sowie Masse des Artikels gespeichert werden.
Schreiben Sie die notwendige Anweisung.
*/




-- ---------------------------------------------------------------------------
-- Aufgabe 5
-- ---------------------------------------------------------------------------
/*
Lassen Sie sich alle Informationen zu den Artikeln anzeigen, die nicht in Bestellpositionen erfasst wurden.
*/





-- ---------------------------------------------------------------------------
-- Aufgabe 6
-- ---------------------------------------------------------------------------
/*
Lassen Sie sich alle Artikel aus der Tabelle l�schen, die nicht in Bestellpositionen erfasst wurden und vom Lieferanten 1020 sind.
*/




