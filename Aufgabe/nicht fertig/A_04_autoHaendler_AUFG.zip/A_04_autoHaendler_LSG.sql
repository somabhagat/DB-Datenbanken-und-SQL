/*
	in dieser Variante werden die Tabellen incl. Fremdschlüsselbeziehungen angelegt --> die Reihenfolge des Anlegens
    der Tabellen ist von ihren FK abhängig
	alternative Variante: Tabellen OHNE Fremdschlüsselbeziehungen in beliebiger Reihenfolge anlegen UND ERST DANACH
    die Fremdschlüsselbeziehungen mit ALTER TABLE hinzufügen
*/

create database autohaendler;
use autohaendler;

create table tbl_mitarbeiter
	(mitarbeiter_Nr int primary key,
	mitarbeiterName char(50));

create table tbl_filialen
	(filial_ID int primary key,
	filialName char(50),
	mitarbeiter_Nr int,
    foreign key (mitarbeiter_Nr) references tbl_mitarbeiter(mitarbeiter_Nr));

create table tbl_hersteller
	(hersteller_ID int primary key,
	herstellerName char(100),
	haendlerNummer int);

create table tbl_modell
	(modell_ID int primary key,
	modellBezeichnung char(100),
	hersteller_ID int,
    foreign key (hersteller_ID) references tbl_hersteller(hersteller_ID));

create table tbl_fahrzeug
	(FIN char(16) primary key,
	fahrzeugFarbe char(20),
	modell_ID int,
    foreign key (modell_ID) references tbl_modell(modell_ID),
	filial_ID int,
    foreign key (filial_ID) references tbl_filialen(filial_ID));

create table tbl_kaufVertrag
	(kaufVertrag_Nr int primary key,
	kaufVertrag_Datum date,
	FIN char(16) unique not null, 			-- damit die Kardinalität 1:c erfüllt ist
    foreign key (FIN) references tbl_fahrzeug(FIN));