-- Bei Bedarf:
-- Öffnen Sie das gegebene Skript und lassen Sie darüber die Datenbank in MS-SQL erstellen.
-- Lassen Sie sich das Datenbank-Diagramm erstellen

-- Lösen Sie in dieser Datenbank folgende Aufgaben mit Hilfe der richtigen SQL-Anweisungen.
-- HINWEIS: Verschaffen Sie sich zunächst einen Überblick über ALLE Aufgaben und lösen Sie die
-- für Sie einfachsten Aufgaben zuerst. Beachten Sie dabei aber, dass es auch Aufgaben gibt, die aufeinander
-- aufbauen, also nur in einer bestimmten Reihenfolge gelöst werden können.

use wawi;

-- ------------------------------------------------------------------------------------------------------------
-- AUFGABE 1: Geben Sie eine Liste mit den Personal-Nr. und den Nachnamen der 
-- Mitarbeiter/ Personal aus, die keine Bestellung bearbeiten.

select * from personal;
select * from bestellungen;

-- right join
select 
	*
	from bestellungen right join personal
	on bestellungen.bearbeiter = personal.persnr
	where bestnr is null;

-- left join
select 
	*
	from personal left join bestellungen
	on bestellungen.bearbeiter = personal.persnr
	where bestnr is null;

-- das ist die richtige Lösung mit den korrekten Spalten
select 
	personal.persnr,
	personal.nachname
	from bestellungen right join personal
	on bestellungen.bearbeiter = personal.persnr
	where bestnr is null;

select 
	p.persnr as 'Personal-Nr.', 
	p.nachname as 'Nachnamen' 
from personal p 
where p.persnr NOT IN (select p.persnr from personal p INNER JOIN bestellungen b ON b.bearbeiter = p.persnr);
-- Variante mit nicht korrelierendem subselect ---> aber mit ineffizientem subselect

select 	
	personal.persnr,	
	personal.nachname
from personal
where personal.persnr NOT IN (select bearbeiter from bestellungen);
-- Variante mit nicht korrelierendem subselect ---> aber mit besserem subselect

-- ------------------------------------------------------------------------------------------------------------
-- AUFGABE 2: Wieviel Artikel befinden sich in der Datenbank? 
-- Sind hier die Artikelbezeichnungen aus der Tabelle artikel gemeint ODER die physisch vorhandenen Artikel aus der
-- Tabelle lagerstand?

select * from artikel;
select * from lagerstand;

select COUNT(*) from artikel;		-- das ist die Anzahl der verschiedenen Artikelbezeichnungen
select sum(menge) from lagerstand;	-- das ist die Anzahl physisch vorhandener Artikel

-- ------------------------------------------------------------------------------------------------------------
-- AUFGABE 3: Welche Artikel sind NICHT in Bestellpositionen erfasst?

-- Vorüberlegung
select 
	*
	from bestellpositionen inner join artikel
		on bestellpositionen.artikel = artikel.artnr;

select 
	*
	from bestellpositionen right join artikel
		on bestellpositionen.artikel = artikel.artnr;

-- das ist die Lösung
select 
	*
	from bestellpositionen right join artikel
		on bestellpositionen.artikel = artikel.artnr
	where bestellpositionen.bestnr is null;


-- ------------------------------------------------------------------------------------------------------------
-- AUFGABE 4: Wieviel Artikel sind NICHT in Bestellpositionen erfasst?

-- Schritt 1
select * from bestellpositionen;

-- Schritt 2
select 
	*
	from bestellpositionen join artikel
		on bestellpositionen.artikel = artikel.artnr;

-- Schritt 3
select 
	*
	from bestellpositionen right join artikel
		on bestellpositionen.artikel = artikel.artnr;

-- Schritt 4
select 
	*
	from bestellpositionen right join artikel
		on bestellpositionen.artikel = artikel.artnr
	where bestellpositionen.bestnr is null
    limit 10000;				-- zeigt sonst nur standardmäßig die ersten 1000 Zeilen an

-- ... und das ist die Lösung:
select 
	COUNT(*)
	from bestellpositionen right join artikel
		on bestellpositionen.artikel = artikel.artnr
	where bestellpositionen.bestnr is null;

-- ------------------------------------------------------------------------------------------------------------
-- AUFGABE 5: Erstellen Sie eine Liste, die zur Bestellung mit der Bestell-Nr. 1004
-- folgende Informationen anzeigt:
-- Artikel-Nr., Bezeichnung des Artikels, bestellte Menge, Preis des Artikels, Gesamtpreis
-- der einzelnen Positionen (also Produkt aus Menge und Preis).
-- Verwenden Sie für die Spalten aussagekräftige Überschriften.

select *
from bestellpositionen;

select *
from bestellpositionen
where bestnr = 1004;

-- das sind die einzelnen Positionen (das ist die Lösung)
select	bestellpositionen.bestnr,
		bestellpositionen.artikel,
		artikel.bezeichnung,
		bestellpositionen.menge,
		bestellpositionen.preis,
		menge*preis as 'Der Positionspreis ist: '
	from bestellpositionen join artikel
		on bestellpositionen.artikel = artikel.artnr
	where bestnr = 1004;

-- das ist die gesamte Bestellung (war nicht gefordert)
select	SUM(menge*preis) as 'Bestellung'
	from bestellpositionen join artikel
		on bestellpositionen.artikel = artikel.artnr
	where bestnr = 1004;


-- ------------------------------------------------------------------------------------------------------------	
-- AUFGABE 6: Erstellen Sie eine Artikel-Liste zur Artikelgruppe "GA" 
-- mit folgenden Angaben: Artikel-Nr., Artikel-Bezeichnung, Einkaufspreis, Lieferanten-Nr.,
-- vollständigem Lieferanten-Firmennamen (in einer Spalte), PLZ, Ort und erster Telefon-Nr.
-- Die Liste soll nach Lieferanten-Nr. aufsteigend sortiert sein.

select 
	artikel.artnr,
	artikel.bezeichnung,
	artikel.ekpreis,
	lieferanten.liefnr,
	concat(lieferanten.firma1, ' ', lieferanten.firma2) AS 'Firmen-Name',
	lieferanten.plz,
	lieferanten.ort,
	lieferanten.tel1
	from artikel join lieferanten
		on artikel.lief = lieferanten.liefnr
	where gruppe = 'GA'
	order by lieferanten.liefnr ASC;

	