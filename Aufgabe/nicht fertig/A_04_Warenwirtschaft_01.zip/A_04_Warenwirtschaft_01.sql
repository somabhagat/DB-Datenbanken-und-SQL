-- Bei Bedarf:
-- Öffnen Sie das gegebene Skript und lassen Sie darüber die Datenbank WaWi erstellen.
-- Lassen Sie sich das Datenbank-Diagramm erstellen.

-- Lösen Sie in dieser Datenbank folgende Aufgaben mit Hilfe der richtigen SQL-Anweisungen.
-- HINWEIS: Verschaffen Sie sich zunächst einen Überblick über ALLE Aufgaben und lösen Sie die
-- für Sie einfachsten Aufgaben zuerst. Beachten Sie dabei aber, dass es auch Aufgaben gibt, die aufeinander
-- aufbauen, also sinnvoll in einer bestimmten Reihenfolge gelöst werden sollten.

use wawi;

-- ------------------------------------------------------------------------------------------------------------
-- AUFGABE 1: Geben Sie eine Liste mit den Personal-Nr. und den Nachnamen der 
-- Mitarbeiter/ Personal aus, die keine Bestellung bearbeiten.



-- ------------------------------------------------------------------------------------------------------------
-- AUFGABE 2: Wieviel Artikel befinden sich in der Datenbank? 



-- ------------------------------------------------------------------------------------------------------------
-- AUFGABE 3: Welche Artikel sind NICHT in Bestellpositionen erfasst?



-- ------------------------------------------------------------------------------------------------------------
-- AUFGABE 4: Wieviel Artikel sind NICHT in Bestellpositionen erfasst?




-- ------------------------------------------------------------------------------------------------------------
-- AUFGABE 5: Erstellen Sie eine Liste, die zur Bestellung mit der Bestell-Nr. 1004
-- folgende Informationen anzeigt:
-- Artikel-Nr., Bezeichnung des Artikels, bestellte Menge, Preis des Artikels, Gesamtpreis
-- der einzelnen Positionen (also Produkt aus Menge und Preis).
-- Verwenden Sie für die Spalten aussagekräftige Überschriften.



-- ------------------------------------------------------------------------------------------------------------	
-- AUFGABE 6: Erstellen Sie eine Artikel-Liste zur Artikelgruppe "GA" 
-- mit folgenden Angaben: Artikel-Nr., Artikel-Bezeichnung, Einkaufspreis, Lieferanten-Nr.,
-- vollständigem Lieferanten-Firmennamen (in einer Spalte), PLZ, Ort und erster Telefon-Nr.
-- Die Liste soll nach Lieferanten-Nr. aufsteigend sortiert sein.



