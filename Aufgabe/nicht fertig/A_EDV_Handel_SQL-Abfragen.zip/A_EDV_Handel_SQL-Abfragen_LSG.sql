/*	---------------------------------------------------------------------------------------
	Verschiedene Abfragen ... Übungen
	--------------------------------------------------------------------------------------- */

-- Verwenden Sie die Datenbank edvhandel
use edvhandel;

-- ---------------------------------------------------------------------------------------------------
-- (1) Liste mit Anzahl der Kunden je Ort. Die Liste soll so sortiert sein,
-- dass der Ort mit der größten Anzahl von Kunden an erster Stelle steht
-- HINWEIS: Aufgaben mit der Formulierung "...je..." deuten häufig darauf hin, dass GROUP BY verwendet werden muss

select
	ORT,
	count(ORT) 'Anzahl Kunden'
from
	KUNDE
group by ORT
order by count(ORT) desc;


-- ---------------------------------------------------------------------------------------------------
-- (2) Liste die angibt, wieviel Artikel je Kategorie gespeichert sind

-- HINWEIS: Hier muss unterschieden werden, ob es um den Bestand an physisch vorhandenen 
-- Artikeln je Kategorie geht ODER um unterschiedliche Artikel-Typen je Kategorie
-- z.B. in Kategorie DRUCKER sind vorhanden die Typen BJC-800, BJC-1200, BJC-2400
-- in Kategorie DRUCKER sind vorhanden die Typen	BJC-800 = 50 physische Geräte, 
--													BJC-1200 = 25 Geräte
--													BJC-2400 = 25 Geräte
-- die physischen Geräte könnten über Serien-Nummer oder über Inventar-Nummer eindeutig identifiziert werden
-- die Artikel-Nr. sind i.d.R. den Typ-Bezeichnungen (=Geräte-Klassen) zugeordnet

-- diese Abfrage liefert den Bestand an physischen Geräten je Kategorie
SELECT
	KATEGORIE, SUM(BESTAND) AS 'aktueller Bestand'
FROM
	ARTIKEL
GROUP BY KATEGORIE;

-- diese Abfrage liefert die Anzahl unterschiedlicher Typen je Kategorie
select
	KATEGORIE,
	COUNT(KATEGORIE) 'Anzahl Artikel'
from
	ARTIKEL
group by KATEGORIE;


-- ---------------------------------------------------------------------------------------------------
-- (3) Wie groß sind die Bestellwerte der einzelnen Kunden-Nummern?

-- funktioniert, aber JOIN ist hier noch nicht notwendig
select
	KUNDE.KUNDENNR,
	sum(BESTELLUNG.RECHNUNGSBETRAG) 'Betrag'
	from KUNDE join BESTELLUNG
		on KUNDE.KUNDENNR = BESTELLUNG.KUNDENNR
group by KUNDE.KUNDENNR;


-- die Lösung ist besser, weil sie minimal = optimal ist
SELECT
	KUNDENNR, 
	SUM(RECHNUNGSBETRAG) as 'Rechnungsbetrag Kunde'
from
	BESTELLUNG
GROUP BY KUNDENNR;

select
	BESTELLUNG.KUNDENNR,
	SUM(RECHNUNGSBETRAG) 'RE-Summe'
from
	BESTELLUNG
group by KUNDENNR;


-- ---------------------------------------------------------------------------------------------------
-- (4) Wie groß ist der Bestellwert der einzelnen Kunden-Nummern? Geben Sie zu der Kunden-Nummer den Kunden-Namen an.


select
	BESTELLUNG.KUNDENNR,
	KUNDE.NAME,
	SUM(RECHNUNGSBETRAG) 'RE-Summe'
from
	BESTELLUNG join KUNDE
		on BESTELLUNG.KUNDENNR = KUNDE.KUNDENNR
group by BESTELLUNG.KUNDENNR, KUNDE.NAME;

SELECT
	KUNDE.KUNDENNR, 
	KUNDE.NAME, 
	SUM(RECHNUNGSBETRAG) as 'Rechnungsbetrag Kunde'
	FROM
	BESTELLUNG join KUNDE
	on BESTELLUNG.KUNDENNR = KUNDE.KUNDENNR
GROUP BY KUNDE.KUNDENNR, KUNDE.NAME;

-- ---------------------------------------------------------------------------------------------------
-- (5) Wie groß ist der Bestellwert der einzelnen Kunden-Nummern 
-- mit Bestellungen > 500  ? Lassen Sie die Liste nach dem Bestellwert sortieren.
-- HINWEIS: Verwenden Sie die Funktion GROUP BY zusammen mit dem Filter HAVING


SELECT
	SUM(RECHNUNGSBETRAG) as 'Gesamt Bestellwert',
	KUNDENNR
from
	BESTELLUNG
GROUP BY KUNDENNR, RECHNUNGSBETRAG
HAVING RECHNUNGSBETRAG > 500;

select
	BESTELLUNG.KUNDENNR,
	SUM(RECHNUNGSBETRAG)
from
	BESTELLUNG
group by KUNDENNR
having SUM(RECHNUNGSBETRAG) > 500
order by SUM(RECHNUNGSBETRAG);

select
	KUNDE.KUNDENNR,
	sum(BESTELLUNG.RECHNUNGSBETRAG) 'Betrag'
from KUNDE join BESTELLUNG
on KUNDE.KUNDENNR = BESTELLUNG.KUNDENNR
group by KUNDE.KUNDENNR having sum(BESTELLUNG.RECHNUNGSBETRAG) > 500;


-- ---------------------------------------------------------------------------------------------------
-- (6) Wie heißen die beiden Artikel mit dem größten bzw. dem kleinsten Nettopreis? Verwenden Sie Subselects.

-- Lösung mit 2 Einzelabfragen und UNION
select
	BEZEICHNUNG,
	NETTOPREIS
from
	ARTIKEL
	where NETTOPREIS = (Select min(NETTOPREIS) from ARTIKEL)
UNION
select
	BEZEICHNUNG,
	NETTOPREIS
from
	ARTIKEL
where NETTOPREIS = (Select max(NETTOPREIS) from ARTIKEL);


SELECT   'MIN-Preis' ' '
         , BEZEICHNUNG
         , MIN(NETTOPREIS) AS 'PREIS'
    FROM ARTIKEL
   WHERE NETTOPREIS = (SELECT MIN(NETTOPREIS) FROM ARTIKEL)
GROUP BY BEZEICHNUNG
UNION
SELECT   'MAX-Preis' ' '
         , BEZEICHNUNG
         , MAX(NETTOPREIS)
    FROM ARTIKEL
   WHERE NETTOPREIS = (SELECT MAX(NETTOPREIS) FROM ARTIKEL)
GROUP BY BEZEICHNUNG;

-- Lösung über WHERE und logische Verknüpfung
select
	BEZEICHNUNG,
	NETTOPREIS
from
	ARTIKEL
where NETTOPREIS = (select min(NETTOPREIS) from ARTIKEL)
	OR NETTOPREIS = (select max(NETTOPREIS) from ARTIKEL);




-- ---------------------------------------------------------------------------------------------------
-- (7) Lassen Sie sich aus der aktuellen Systemzeit Ihres DBS die Sekunden anzeigen. (nur die Sekunden, ohne Datum, Stunden usw.)
-- HINWEIS: Verwenden Sie die richtige Zeitfunktion sowie Stringfunktionen.

select 
	sysdate(),
    current_timestamp(),
    curtime(),
    substring(sysdate(), 18,2),
    right(current_timestamp(), 2);
