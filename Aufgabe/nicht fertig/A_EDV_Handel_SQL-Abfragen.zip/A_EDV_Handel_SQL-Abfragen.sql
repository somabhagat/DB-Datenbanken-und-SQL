/*	---------------------------------------------------------------------------------------
	Verschiedene Abfragen ... �bungen
	--------------------------------------------------------------------------------------- */

-- Verwenden Sie die Datenbank edvhandel
use edvhandel;

-- ---------------------------------------------------------------------------------------------------
-- (1) Liste mit Anzahl der Kunden je Ort. Die Liste soll so sortiert sein,
-- dass der Ort mit der gr��ten Anzahl von Kunden an erster Stelle steht
-- HINWEIS: Aufgaben mit der Formulierung "...je..." deuten h�ufig darauf hin, dass GROUP BY verwendet werden muss





-- ---------------------------------------------------------------------------------------------------
-- (2) Liste die angibt, wieviel Artikel je Kategorie gespeichert sind

-- HINWEIS: Hier muss unterschieden werden, ob es um den Bestand an physisch vorhandenen 
-- Artikeln je Kategorie geht ODER um unterschiedliche Artikel-Typen je Kategorie
-- z.B. in Kategorie DRUCKER sind vorhanden die Typen BJC-800, BJC-1200, BJC-2400
-- in Kategorie DRUCKER sind vorhanden die Typen	BJC-800 = 50 physische Ger�te, 
--													BJC-1200 = 25 Ger�te
--													BJC-2400 = 25 Ger�te
-- die physischen Ger�te k�nnten �ber Serien-Nummer oder �ber Inventar-Nummer eindeutig identifiziert werden
-- die Artikel-Nr. sind i.d.R. den Typ-Bezeichnungen (=Ger�te-Klassen) zugeordnet







-- ---------------------------------------------------------------------------------------------------
-- (3) Wie gro� sind die Bestellwerte der einzelnen Kunden-Nummern?







-- ---------------------------------------------------------------------------------------------------
-- (4) Wie gro� ist der Bestellwert der einzelnen Kunden-Nummern? Geben Sie zu der Kunden-Nummer den Kunden-Namen an.








-- ---------------------------------------------------------------------------------------------------
-- (5) Wie gro� ist der Bestellwert der einzelnen Kunden-Nummern 
-- mit Bestellungen > 500 � ? Lassen Sie die Liste nach dem Bestellwert sortieren.
-- HINWEIS: Verwenden Sie die Funktion GROUP BY zusammen mit dem Filter HAVING







-- ---------------------------------------------------------------------------------------------------
-- (6) Wie hei�en die beiden Artikel mit dem gr��ten bzw. dem kleinsten Nettopreis? Verwenden Sie Subselects.





-- ---------------------------------------------------------------------------------------------------
-- (7) Lassen Sie sich aus der aktuellen Systemzeit Ihres DBS die Sekunden anzeigen. (nur die Sekunden, ohne Datum, Stunden usw.)
-- HINWEIS: Verwenden Sie die richtige Zeitfunktion sowie Stringfunktionen.






