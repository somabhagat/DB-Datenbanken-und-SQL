use versicherung;


/* 1. F�gen Sie der Datenbank die Tabelle �tbl_inventar� hinzu. 
Verwenden Sie die dargestellten Felder und Datentypen. Diese 
neue Tabelle soll �ber das Feld �inventar_in_abt� durch eine 
Fremdschl�sselbeziehung mit der vorhandenen Tabelle �Abteilung� verkn�pft sein.
*/
create table tbl_inventar
	(inventar_id int auto_increment primary key,
	inventar_nr char(35),
	inventar_bezeichnung char(150),
	inventar_in_abt int,
	foreign key (inventar_in_abt) references Abteilung(ID),
	inventar_in_raum varchar(10));


/*2. Sie sollen der Tabelle �Mitarbeiter� eine Spalte f�r die Erfassung 
der steuerlichen Identifikationsnummer hinzuf�gen.*/

alter table Mitarbeiter add StIdNr char(11);