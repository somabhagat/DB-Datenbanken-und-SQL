create database kindergarten;
use kindergarten;

create table tbl_kindergartengruppe 
(gruppen_id int,
gruppenName char(100) not null,
constraint PK_tbl_kindergartengruppe primary key (gruppen_id));

create table tbl_verkehrsmittel
(verkehrsmittelNummer smallint,
verkehrsmittelBezeichnung char(100) not null,
constraint PK_tbl_verkehrsmittel primary key (verkehrsmittelNummer));

create table tbl_mahlzeit
(mahlzeitNummer smallint,
mahlzeitBezeichnung char(100) not null,
constraint PK_tbl_mahlzeit primary key (mahlzeitNummer));

create table tbl_kind
(kindNummer smallint,
kindGeburtsdatum date not null,
kindNachname char(150) not null,
kindVorname char(150),
gruppen_id int,
verkehrsmittelNummer smallint, 
constraint PK_tbl_kind primary key (kindNummer),
constraint FK_tbl_kind_tbl_verkehrsmittel foreign key (verkehrsmittelNummer)
	references tbl_verkehrsmittel(verkehrsmittelNummer),
constraint FK_tbl_kind_tbl_kindergartengruppe foreign key (gruppen_id)
	references tbl_kindergartengruppe(gruppen_id));

create table tbl_kind_isst_mahlzeit
(kindNummer smallint,
mahlzeitNummer smallint,
constraint PK_tbl_kind_isst_mahlzeit primary key (kindNummer, mahlzeitNummer),
constraint FK_tbl_kind_isst_mahlzeit_tbl_kind foreign key (kindNummer)
	references tbl_kind(kindNummer),
constraint FK_tbl_kind_isst_mahlzeit_tbl_mahlzeit foreign key (mahlzeitNummer)
	references dbo.tbl_mahlzeit);

