use kindergarten;

insert into 
	tbl_verkehrsmittel(verkehrsmittelNummer,verkehrsmittelBezeichnung)
values 
	(1,'Auto'),
	(2,'Tram'),
	(4,'sonstige'),
	(11,'Fahrrad');

insert into 
	tbl_mahlzeit 
values 
	(1,'Frühstück'),(2,'Mittag'),(3,'Abendessen');

insert into 
	tbl_kindergartengruppe(gruppen_id,gruppenName)
values 
	(1, 'Sonne'),(2,'Schmetterling'),(3,'Bärchen');

insert into 
	tbl_kind(kindNummer,kindGeburtsdatum,kindNachname,kindVorname,gruppen_id,verkehrsmittelNummer) 
values
	(13,'29.05.2010','Kelch','Sabrina',1,4),
	(14,'03.04.2010','Winter','Sven',1,2),
	(15,'07.12.2009','Karstens','Anna',2,1),
	(16,'30.03.2010','Preil','Verena',3,11);


insert into
	tbl_kind_isst_mahlzeit
values
	(13,1),
	(14,3),
	(15,1),
	(15,2),
	(16,1),
	(16,2);
