# Musterlösung zu FPA_04_01_01_bis_03 (d)

INSERT INTO Kontinent(Kontinent_Name)
VALUES 
("Amerika"),
("Europa"),
("Afrika"),
("Asien"),
("Australien");

INSERT INTO Land(Kontinent_ID,Land_Name)
VALUES 
(1,"Mexiko"),
(2,"Österreich"),
(2,"Norwegen"),
(3,"Tunesien"),
(4,"Japan"),
(5,"Neuseeland");

INSERT INTO Region(Land_ID,Region_Name)
VALUES 
(1,"Chiapas"),
(2,"Tirol"),
(2,"Burgenland"),
(3,"Troms"),
(4,"Kebili"),
(5,"Hokkaido"),
(6,"Wellington");

INSERT INTO Stadt(Region_ID,Stadt_Name)
VALUES 
(1,"Tuxtla Gutiérrez"),
(2,"Bozen"),
(2,"Meran"),
(3,"Eisenstadt"),
(4,"Berg"),
(5,"Douz"),
(6,"Shibetsu"),
(7,"Hutt City");