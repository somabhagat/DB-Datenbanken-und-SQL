# Musterlösung zu FPA_04_01_01_bis_03 (c)


CREATE DATABASE FPA_04_01_01_bis_03_c;
USE FPA_04_01_01_bis_03_c;

CREATE TABLE Kontinent
(
    Kontinent_ID INT(11) AUTO_INCREMENT,
    Kontinent_Name VARCHAR(255),
    PRIMARY KEY(Kontinent_ID)
);

CREATE TABLE Land
(
    Land_ID INT(11) AUTO_INCREMENT,
    Kontinent_ID INT(11),
    Land_Name VARCHAR(255),
    PRIMARY KEY(Land_ID),
	FOREIGN KEY(Kontinent_ID) REFERENCES Kontinent(Kontinent_ID)
);

CREATE TABLE Region
(
    Region_ID INT(11) AUTO_INCREMENT,
    Land_ID INT(11),
    Region_Name VARCHAR(255),
    PRIMARY KEY(Region_ID),
    FOREIGN KEY(Land_ID) REFERENCES Land(Land_ID)
);

CREATE TABLE Stadt
(
    Stadt_ID INT(11) AUTO_INCREMENT,
    Region_ID INT(11),
    Stadt_Name VARCHAR(255),
    PRIMARY KEY(Stadt_ID),
    FOREIGN KEY(Region_ID) REFERENCES Region(Region_ID)
);