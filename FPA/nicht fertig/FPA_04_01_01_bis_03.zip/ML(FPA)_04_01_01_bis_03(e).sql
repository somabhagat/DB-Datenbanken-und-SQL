# Musterlösung zu FPA_04_01_01_bis_03 (e)



#(1)
UPDATE Region SET Region_Name="Troms og Finnmark" WHERE Region_Name="Troms";


#(2)
UPDATE Region SET Region_Name="Troms og Finnmark" 
WHERE Region_ID=(SELECT Region_ID FROM Region WHERE Region_Name="Troms");

# ERLÄUTERUNG:
# Falls der Subselect einen EINZIGEN Wert liefert (und also nur eine Region namens "Troms" existiert), so arbeitet diese Lösung wie in (1).
# Falls jedoch der Subselect MEHRERE Werte ausgibt (weil es mehrere Regionen namens "Troms" gibt), so erscheint eine Fehlermeldung, ...
# ... da in diesem Fall die WHERE-Klausel nicht abgearbeitet werden kann, denn "Region_ID" kann nicht "gleich" mehrere Werte sein. 

# HINWEIS:
# Man könnte diese Fehlermeldung zwar durch die Änderung der WHERE-Klausel mittels IN-Operator vermeiden: "WHERE Region_ID IN (...)" ...
# ... dies würde aber wieder dazu führen, dass ausnahmslos alle Regionen namens "Troms" umbenannt werden würden ...
# ... (und eben nicht nur jene in Norwegen)


#(3)
ALTER TABLE Stadt RENAME Ortschaft;