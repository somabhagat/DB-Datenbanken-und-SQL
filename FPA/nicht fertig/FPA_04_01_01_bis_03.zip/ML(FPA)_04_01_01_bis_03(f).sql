# Musterlösung zu FPA_04_01_01_bis_03 (f)



#(1)
INSERT INTO Ortschaft(Region_ID,Stadt_Name)
VALUES (NULL,"Entenhausen");

INSERT INTO Kontinent(Kontinent_Name)
VALUES ("Phantasia");


#(2)
SELECT
	Stadt_Name,
    Region_Name,
    Land_Name,
    Kontinent_Name
FROM Ortschaft LEFT JOIN Region ON Ortschaft.Region_ID=Region.Region_ID
     LEFT JOIN Land ON Region.Land_ID=Land.Land_ID
     LEFT JOIN Kontinent ON Land.Kontinent_ID=Kontinent.Kontinent_ID
UNION
SELECT
	Stadt_Name,
    Region_Name,
    Land_Name,
    Kontinent_Name
FROM Ortschaft RIGHT JOIN Region ON Ortschaft.Region_ID=Region.Region_ID
     RIGHT JOIN Land ON Region.Land_ID=Land.Land_ID
     RIGHT JOIN Kontinent ON Land.Kontinent_ID=Kontinent.Kontinent_ID;
	 
	 
#(3)
ALTER TABLE Land DROP FOREIGN KEY Land_ibfk_1;
ALTER TABLE Land ADD FOREIGN KEY(Kontinent_ID) 
REFERENCES Kontinent(Kontinent_ID) ON DELETE CASCADE;

ALTER TABLE Region DROP FOREIGN KEY Region_ibfk_1;
ALTER TABLE Region ADD FOREIGN KEY(Land_ID) 
REFERENCES Land(Land_ID) ON DELETE CASCADE;

ALTER TABLE Ortschaft DROP FOREIGN KEY Ortschaft_ibfk_1;
ALTER TABLE Ortschaft ADD FOREIGN KEY(Region_ID) 
REFERENCES Region(Region_ID) ON DELETE CASCADE;

#Test
DELETE FROM Kontinent WHERE Kontinent_Name="Europa";