use edvhandel;

-- (1) Erstellen Sie eine Mitarbeiter-Liste mit Mitarbeiter-Nr., Vorname, Name, Abteilungs-Nr., 
-- Abteilungs-Bezeichnung, Telefon-Nr.
select * from mitarbeiter;

select 
	MITARBEITER_NR,
	VORNAME,
	Name,
	ABTEILUNG,
	BEZEICHNUNG,
	TEL
from 
	MITARBEITER 
		JOIN ABTEILUNG ON MITARBEITER.ABTEILUNG = ABTEILUNG.ABTEILUNGS_NR;


-- (2) Erstellen Sie eine Mitarbeiter-Liste mit Mitarbeiter-Nr., Vorname, Name, Abteilungs-Nr., 
-- Abteilungs-Bezeichnung, Telefon-Nr.
-- Verwenden Sie in der FROM ... JOIN ... ON - Klausel Aliasse für die Tabellen
select 
	MITARBEITER_NR,
	VORNAME,
	Name,
	ABTEILUNG,
	BEZEICHNUNG,
	TEL
from 
	MITARBEITER AS m
		JOIN ABTEILUNG AS a ON m.ABTEILUNG = a.ABTEILUNGS_NR;


-- (3) Liste mit allen Feldern der Tabelle 'Artikel' und zu jedem Artikel die jeweilige Bezeichnung der Kategorie
select 
	a.*,			-- von der Tabelle artikel werden so alle Spalten angezeigt
	k.BEZEICHNUNG
from 
	ARTIKEL a join KATEGORIE k on a.KATEGORIE_NR = k.KATEGORIE_NR;


-- (4) Liste aller Artikel-Posten, die in der Bestellung Nr. 1 sind. Zu den Artikeln soll die Bezeichnung ausgegeben werden.

select 
	p.BESTELL_NR,
	p.ARTIKEL_NR,
	a.BEZEICHNUNG,
	p.BESTELLMENGE,
	p.LIEFERMENGE
from
	POSTEN p join ARTIKEL a on p.ARTIKEL_NR = a.ARTIKEL_NR 
where p.BESTELL_NR = 1;
