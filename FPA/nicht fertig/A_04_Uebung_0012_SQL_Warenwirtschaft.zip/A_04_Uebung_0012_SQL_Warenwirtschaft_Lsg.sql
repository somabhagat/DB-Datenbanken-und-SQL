/*
	L�sen Sie folgende Aufgaben auf der Datenbank Warenwirtschaft (WaWi)
*/
use wawi;

-- insert, update, delete
-- tabellenstruktur ver�ndern

-- ---------------------------------------------------------------------------
-- Aufgabe 1
-- ---------------------------------------------------------------------------
/*F�gen Sie folgende Artikel in die richtige Tabelle ein:
Bezeichnung					Gruppe		Verkaufspreis	Lieferant 
Adlus Gartenspaten light	GA			29.90			1002
Adlus Gartenspaten middle	GA			35.90			1002
Adlus Gartenspaten heavy	GA			59.95			1002

HINWEIS: Die Spalte artnr muss nicht angegeben werden. Sie wird automatisch vom DBS hochgez�hlt und ausgef�llt.
*/

select * from artikel

insert into artikel (bezeichnung, gruppe, vkpreis, lief) values
	('Adlus Gartenspaten light','GA',29.90,1002),
	('Adlus Gartenspaten middle','GA',35.90,1002),
	('Adlus Gartenspaten heavy','GA',59.95,1002)



-- ---------------------------------------------------------------------------
-- Aufgabe 2
-- ---------------------------------------------------------------------------
/* F�gen Sie folgende Lieferanten hinzu:

Lieferanten-Nr		Firma1					Firma2				PLZ			Ort			Telefon			Erfasst
1135				Krempel KG									10340		Berlin		030 1234432		17.10.2018
2010				GZ Manufaktur GmbH							8010		Graz		0316 556699		17.10.2018
2011				K�chenhelfer AG			M�ller & T�chter	81377		M�nchen		089 33554411	17.10.2018
2055				Baumschule Franz		GmbH				39596		Beelitz		039321 78652	17.10.2018
*/

select * from lieferanten
delete from lieferanten where liefnr=1135 or liefnr=2010or liefnr=2011 or liefnr=2055

insert into lieferanten (liefnr, firma1, firma2, plz, ort, tel1, erfasst) values
	(1135,'Krempel KG','','10340','Berlin','030 1234432','17.10.2018'),
	(2010,'GZ Manufaktur GmbH','','8010','Graz','0316 556699','17.10.2018'),
	(2011,'K�chenhelfer AG','M�ller & T�chter','81377','M�nchen','089 33554411','17.10.2018'),
	(2055,'Baumschule Franz','GmbH','39596','Beelitz','039321 78652','17.10.2018')


-- ---------------------------------------------------------------------------
-- Aufgabe 3
-- ---------------------------------------------------------------------------
/*
F�gen Sie folgende Mitarbeiter hinzu:
persnr	nachname	vorname	geschlecht	abtlg		gebdatum		strasse			land	plz		ort
110		Sonntag		Peter	m			Einkauf		03.08.1981		M�hlenweg 1				36115	Ehrenberg
111		Montag		Marion	w			Marketing	12.09.1995		Heerstra�e 27	D		47441	Moers
*/

select * from personal
select * from abteilungen
delete from personal where persnr=110 or persnr=111

insert into personal (persnr, nachname, vorname, geschlecht, abtlg, gebdatum, strasse, land, plz, ort) values
	(110,'Sonntag','Peter',2,'EK','03.08.1981','M�hlenweg 1','','36115','Ehrenberg'),
	(111,'Montag','Marion',1,'MA','12.09.1995','Heerstra�e 27','D','47441','Moers')

insert into personal (persnr, nachname, vorname, geschlecht, abtlg, gebdatum, strasse, land, plz, ort) values
	(116,'Sonntag','Peter',2,(select abtnr from abteilungen where text='Einkauf'),'03.08.1981','M�hlenweg 1',NULL,'36115','Ehrenberg'),
	(117,'Montag','Marion',1,(select abtnr from abteilungen where text='Marketing'),'12.09.1995','Heerstra�e 27','D','47441','Moers')


-- ---------------------------------------------------------------------------
-- Aufgabe 4
-- ---------------------------------------------------------------------------
/*
F�hren Sie folgende �nderungen an den Personaldaten durch:
a) Korrigieren Sie den Schreibfehler im Datensatz mit der Personalnummer 285.
b) Matthias Pr�gger aus Graz hat geheiratet und seinen Nachnamen in "Niedernissl" ge�ndert. Korrigieren Sie den entsprechenden Datensatz.
c) Bernadette Hille hat ihre Adressangaben geliefert. Sie sollen sie eintragen: PLZ: 94508 Ort: Sch�llnach Stra�e: Am Wasserfall 6
*/

select * from personal
select * from abteilungen

-- a) 
select * from personal where persnr = 285
update personal set nachname = 'Meister'  where persnr = 285

-- b)
select * from personal where nachname = 'Niedernissl'

update personal set nachname = 'Niedernissl'  where nachname = 'Pr�gger' and vorname = 'Matthias' and ort = 'Graz'
update personal set nachname = 'Niedernissl'  where persnr = 755
select * from personal where persnr = 755

-- c)
select * from personal where nachname = 'Hille'
update personal set plz='94508', ort = 'Sch�llnach', strasse = 'Am Wasserfall 6' where nachname = 'Hille'

-- ---------------------------------------------------------------------------
-- Aufgabe 5
-- ---------------------------------------------------------------------------
/*
In der Firma wurde eine neue Abteilung "Reklamationen und Retouren" (K�rzel RR) eingerichtet.
Die Mitarbeiterin 674 und Herr N�rnberger haben in diese Abteilung gewechselt.
Nehmen Sie alle notwendigen Anpassungen in den Datens�tzen der Datenbank vor
*/

select * from abteilungen
insert into abteilungen(abtnr, text) values ('RR','Reklamationen und Retouren')

select * from personal where persnr=674 or nachname like '%N�rnberger%'

update personal set abtlg = 'RR' where persnr=674 or nachname like '%N�rnberger%'


