/*
	L�sen Sie folgende Aufgaben auf der Datenbank Warenwirtschaft (WaWi)
*/

use wawi;

-- ---------------------------------------------------------------------------
-- Aufgabe 1
-- ---------------------------------------------------------------------------
/*F�gen Sie folgende Artikel in die richtige Tabelle ein:
Bezeichnung					Gruppe		Verkaufspreis	Lieferant 
Adlus Gartenspaten light	GA			29.90			1002
Adlus Gartenspaten middle	GA			35.90			1002
Adlus Gartenspaten heavy	GA			59.95			1002

HINWEIS: Die Spalte artnr muss nicht angegeben werden. Sie wird automatisch vom DBS hochgez�hlt und ausgef�llt.
*/




-- ---------------------------------------------------------------------------
-- Aufgabe 2
-- ---------------------------------------------------------------------------
/* F�gen Sie folgende Lieferanten hinzu:

Lieferanten-Nr		Firma1					Firma2				PLZ			Ort			Telefon			Erfasst
1135				Krempel KG									10340		Berlin		030 1234432		17.10.2018
2010				GZ Manufaktur GmbH							8010		Graz		0316 556699		17.10.2018
2011				K�chenhelfer AG			M�ller & T�chter	81377		M�nchen		089 33554411	17.10.2018
2055				Baumschule Franz		GmbH				39596		Beelitz		039321 78652	17.10.2018
*/




-- ---------------------------------------------------------------------------
-- Aufgabe 3
-- ---------------------------------------------------------------------------
/*
F�gen Sie folgende Mitarbeiter hinzu:
persnr	nachname	vorname	geschlecht	abtlg		gebdatum		strasse			land	plz		ort
110		Sonntag		Peter	m			Einkauf		03.08.1981		M�hlenweg 1				36115	Ehrenberg
111		Montag		Marion	w			Marketing	12.09.1995		Heerstra�e 27	D		47441	Moers
*/





-- ---------------------------------------------------------------------------
-- Aufgabe 4
-- ---------------------------------------------------------------------------
/*
F�hren Sie folgende �nderungen an den Personaldaten durch:
a) Korrigieren Sie den Schreibfehler im Datensatz mit der Personalnummer 285.
b) Matthias Pr�gger aus Graz hat geheiratet und seinen Nachnamen in "Niedernissl" ge�ndert. Korrigieren Sie den entsprechenden Datensatz.
c) Bernadette Hille hat ihre Adressangaben geliefert. Sie sollen sie eintragen: PLZ: 94508 Ort: Sch�llnach Stra�e: Am Wasserfall 6
*/





-- ---------------------------------------------------------------------------
-- Aufgabe 5
-- ---------------------------------------------------------------------------
/*
In der Firma wurde eine neue Abteilung "Reklamationen und Retouren" (K�rzel RR) eingerichtet.
Die Mitarbeiterin 674 und Herr N�rnberger haben in diese Abteilung gewechselt.
Nehmen Sie alle notwendigen Anpassungen in den Datens�tzen der Datenbank vor
*/



