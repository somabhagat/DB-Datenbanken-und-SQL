use entwicklungsabteilung;

-- 1.	Liste mit allen Protokoll-Nummern sowie den jeweils dazugehörigen Projekt-Nummern und –Namen sowie 
-- Versuchsreihen-Nr und –Namen
select 
	pk.*,
	pj.*,
	vr.*
from 
	tbl_protokoll pk join tbl_versuchsreihe vr
		on pk.versuchsreihe_nr = vr.versuchsreihe_nr
	join tbl_projekt pj
		on pj.projekt_nr = vr.projekt_nr;

select 
	pk.protokoll_nr,
	pj.projekt_nr,
	pj.projekt_name,
	vr.versuchsreihe_nr,
	vr.versuchsreihe_name
from 
	tbl_protokoll pk join tbl_versuchsreihe vr
		on pk.versuchsreihe_nr = vr.versuchsreihe_nr
	join tbl_projekt pj
		on pj.projekt_nr = vr.projekt_nr;


-- 2.	Welcher Projektleiter (Mitarbeiternummer, Name, Vorname) verantwortet welches Protokoll (Protokoll-Nr.)? 
select 
	ma.mitarbeiter_nr,
	ma.mitarbeiter_name,
	ma.mitarbeiter_vorname,
	pk.protokoll_nr
from 
	tbl_protokoll pk join tbl_versuchsreihe vr
		on pk.versuchsreihe_nr = vr.versuchsreihe_nr
	join tbl_projekt pj
		on pj.projekt_nr = vr.projekt_nr
	join tbl_mitarbeiter ma
		on ma.mitarbeiter_nr = pj.mitarbeiter_nr_ist_leiter;

-- 3.	Erstellen Sie eine Sicht/ View, die alle Projekte auflistet mit Projekt-Nummer, Projekt-Name, Mitarbeiter-Nummer des Projektleiters, 
-- Name des Projektleiters, Nummer der Forschungsgruppe, Name der Forschungsgruppe und den Stunden der Forschungsgruppe im Projekt. Die Liste 
-- soll absteigend nach den Projektstunden sortiert sein. 

create view projekt_liste as
	select	tbl_projekt.projekt_nr 'Projekt-Nummer',
			tbl_projekt.projekt_name 'Projekt-Name',
			tbl_projekt.mitarbeiter_nr_ist_leiter 'Leiter MA-Nr.',
			tbl_mitarbeiter.mitarbeiter_name 'Leiter Name',
			tbl_entwicklungsgruppe.eg_nummer 'Nr. der Entw.Gruppe',
			tbl_entwicklungsgruppe.eg_name 'Name der Entw.Gruppe',
			tbl_eg_arbeitet_an_projekt.stunden_in_projekt 'Stunden der Entw.Gruppe an Projekt'
		from 
		tbl_projekt join tbl_eg_arbeitet_an_projekt
			on tbl_projekt.projekt_nr = tbl_eg_arbeitet_an_projekt.projekt_nr
		join tbl_entwicklungsgruppe
			on tbl_entwicklungsgruppe.eg_nummer = tbl_eg_arbeitet_an_projekt.eg_nummer
		join tbl_projektleiter
			on tbl_projekt.mitarbeiter_nr_ist_leiter = tbl_projektleiter.mitarbeiter_nr
		join tbl_mitarbeiter
			on tbl_mitarbeiter.mitarbeiter_nr =tbl_projektleiter.mitarbeiter_nr
		order by tbl_eg_arbeitet_an_projekt.stunden_in_projekt desc;

select * from projekt_liste;


-- 4.	Fügen Sie mit der richtigen SQL-Anweisung folgende neue Mitarbeiter in die Datenbank ein:
-- Mitarbeiter-Nr.			Name			Vorname			Entw.Gruppe
/*		122			Sahlmann		Uwe				48
		43			Strauss		Ivonne			29
		127			Heinze		Rita				21
		201			Warstein		Carolin			12
		195			Gerhard		Frank				29
		*/

insert into tbl_mitarbeiter values	
			(122,'Sahlmann','Uwe',48),
			(43,'Strauss','Ivonne',29),
			(127,'Heinze','Rita',21),
			(201,'Warstein','Carolin',12),
			(195,'Gerhard','Frank',29);


-- 5.	Liste mit Anzahl der Protokolle je Versuchsreihe mit Namen der Versuchsreihen. Es sollen nur die Versuchsreihen ausgegeben werden, 
-- die weniger als 4 Protokolle haben.

-- das ist die Ausgangsrelation, aus der die notwendigen Gruppierungen abgelesen werden müssen  --> Versuchsreihen-Nr.
select 
	vr.*,
	pk.*
	
from 
	tbl_protokoll pk join tbl_versuchsreihe vr
		on pk.versuchsreihe_nr = vr.versuchsreihe_nr;

-- aus der vorangegangenen Abfrage wird diese Gruppierung entwickelt
select 
	vr.versuchsreihe_nr,
	vr.versuchsreihe_name 'Name der Versuchsreihe',
	count(vr.versuchsreihe_nr) 'Anzahl der Protokolle in der Versuchsreihe' 
from 
	tbl_protokoll pk join tbl_versuchsreihe vr
		on pk.versuchsreihe_nr = vr.versuchsreihe_nr
group by vr.versuchsreihe_nr, vr.versuchsreihe_name
having count(vr.versuchsreihe_nr) < 4;


-- 6.	Liste mit Anzahl der Mitarbeiter in den Entwicklungsgruppen mit Namen der jeweiligen Entwicklungsgruppe absteigend sortiert nach 
-- Anzahl der Mitarbeiter und aufsteigend nach Namen der Entwicklungsgruppe

select
	ma.eg_nummer,
	eg.eg_name,
	count(ma.eg_nummer) 'Anzahl MA'
from
	tbl_mitarbeiter ma join tbl_entwicklungsgruppe eg
		on ma.eg_nummer = eg.eg_nummer
group by ma.eg_nummer, eg.eg_name
order by count(ma.eg_nummer) desc, eg.eg_name asc;

-- 7.	Liste aller Mitarbeiter, die nicht Leiter eines Projekts sind

select
	*
from
	tbl_mitarbeiter;

select
	*
from
	tbl_projekt;

select
	*
from
	tbl_projektleiter;

select 
	*
from 
	tbl_mitarbeiter ma left join tbl_projektleiter pl
		on ma.mitarbeiter_nr = pl.mitarbeiter_nr
where pl.mitarbeiter_nr is null;

-- 8.	Liste mit der Summe der Stunden, die in jedem Projekt geleistet wurden. 
-- In der Liste sollen Projekt-Nummer, Projekt-Name und die Summe der Projektstunden angezeigt werden.

select 
	p.projekt_name,
	sum(stunden_in_projekt)
from
	tbl_eg_arbeitet_an_projekt a
		join tbl_projekt p
			on a.projekt_nr = p.projekt_nr
group by p.projekt_name;
		

-- 9.	Liste mit der Summe der Stunden, die in jedem Projekt geleistet wurden. 
-- In der Liste sollen Projekt-Nummer, Projekt-Name und die Summe der Projektstunden sowie der Name des Projektleiters angezeigt werden.

select 
	p.projekt_name,
	sum(stunden_in_projekt),
	m.mitarbeiter_name 'Projektleiter'
from
	tbl_eg_arbeitet_an_projekt a
		join tbl_projekt p
			on a.projekt_nr = p.projekt_nr
		join tbl_mitarbeiter m
			on p.mitarbeiter_nr_ist_leiter = m.mitarbeiter_nr
group by p.projekt_name, m.mitarbeiter_name;
