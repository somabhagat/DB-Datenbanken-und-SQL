create database entwicklungsabteilung;
use entwicklungsabteilung;

create table tbl_entwicklungsgruppe
	(eg_nummer smallint primary key,
	eg_name char(100));
	
create table tbl_mitarbeiter
	(mitarbeiter_nr smallint primary key,
	mitarbeiter_name char(50) not null,
	mitarbeiter_vorname char(50),
	eg_nummer smallint,
	foreign key (eg_nummer) references tbl_entwicklungsgruppe(eg_nummer));
	
create table tbl_projektleiter
	(mitarbeiter_nr smallint primary key,
	foreign key (mitarbeiter_nr) references tbl_mitarbeiter(mitarbeiter_nr));

create table tbl_projekt
	(projekt_nr char(4) primary key,
	projekt_name char(100),
	mitarbeiter_nr_ist_leiter smallint unique,
	foreign key (mitarbeiter_nr_ist_leiter)	references tbl_projektleiter(mitarbeiter_nr));
-- UNIQUE als Spalteneigenschaft sorgt dafür, dass jeder Wert in dieser Spalte nur einmal
-- vorkommt (ist aber kein Primärschlüssel)

create table tbl_versuchsreihe
	(versuchsreihe_nr char(4) primary key,
	versuchsreihe_name char(50),
	projekt_nr char(4),
	foreign key (projekt_nr) references tbl_projekt(projekt_nr));

create table tbl_protokoll
	(protokoll_nr smallint primary key,
	versuchsreihe_nr char(4),
	foreign key (versuchsreihe_nr) references tbl_versuchsreihe (versuchsreihe_nr));

create table tbl_eg_arbeitet_an_projekt
	(projekt_nr char(4),
	eg_nummer smallint, 
	stunden_in_projekt decimal(6,2),
	primary key (projekt_nr,eg_nummer),
	foreign key (eg_nummer) references tbl_entwicklungsgruppe(eg_nummer),
	foreign key (projekt_nr) references tbl_projekt(projekt_nr));


/* DATEN */
insert into tbl_entwicklungsgruppe
	values	(23,'Mechanik'),
			(48,'E-Technik'),
			(21,'Akustik'),
			(12,'Hydraulik'),	
			(29,'Gestaltung');

insert into tbl_mitarbeiter
	values	(234,'Schulz','Jürgen',23),
			(260,'Wegner','Rita',48),
			(301,'Salm','Ricardo',21),
			(344,'Weber','Christian',12),
			(521,'Frost','Simone',29);

insert into tbl_projektleiter
	values	(234),(260),(301),(344),(521);

insert into tbl_projekt
	values	('P010','Toaster',234),
			('P023','Grill',301),
			('P011','Haustechnik',260),
			('P078','Armaturen',344),
			('P080','Rohbau',521);

insert into tbl_versuchsreihe
	values	('V001','Stromversorgung','P010'),
			('V010','Sensoren','P010'),
			('V003','Zeitsteuerung','P011'),
			('V004','LAN-Anbindung','P011'),
			('V112','Tofu-Schnitzel','P023'),
			('V021','Lebensdauer','P078'),
			('V131','Fernsteuerung','P078'),
			('V015','Witterungsschutz','P080');

insert into tbl_protokoll
	values	(23,'V001'),
	(34,'V001'),
	(12,'V001'),
	(35,'V010'),
	(132,'V010'),
	(2,'V003'),
	(7,'V003'),
	(69,'V003'),
	(4,'V004'),
	(37,'V112'),
	(28,'V112'),
	(96,'V112'),
	(11,'V021'),
	(17,'V021'),
	(57,'V021'),
	(61,'V021'),
	(156,'V131'),
	(33,'V015'),
	(72,'V015'),
	(19,'V015'),
	(13,'V015');

insert into tbl_eg_arbeitet_an_projekt
	values	('P010',23,34),
			('P023',23,26),
			('P011',48,199),
			('P023',48,80),
			('P023',21,47),
			('P078',21,7),
			('P080',21,52),
			('P078',12,117),
			('P080',12,11),
			('P010',29,70),
			('P080',29,39);
			
