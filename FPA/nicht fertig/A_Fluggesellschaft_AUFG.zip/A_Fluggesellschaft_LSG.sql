/* Fluggesellschaft */

create database intoTheSun;
use intoTheSun;

create table Flughafen
(FHkuerzel char(3),
Stadt varchar(100),
primary key (FHkuerzel));

create table FlugzeugTyp
(Typbezeichnung varchar(150),
Sitzanzahl tinyint,
primary key (Typbezeichnung));

create table Pilot
(PersonalNummer varchar(5),
Name varchar(100),
Vorname varchar(100),
primary key(PersonalNummer));

create table Typberechtigung
(Personalnummer varchar(5),
Typbezeichnung varchar(150),
primary key (Personalnummer, Typbezeichnung),
foreign key (Personalnummer) references Pilot(PersonalNummer),
foreign key (Typbezeichnung) references FlugzeugTyp(Typbezeichnung));

create table Flugzeug
(FlugzeugName varchar(100),
Typbezeichnung varchar(150),
primary key (FlugzeugName),
foreign key (Typbezeichnung) references FlugzeugTyp(Typbezeichnung));

create table Flug
(FlugNr varchar(6),
Abflugzeit time,
Ankunftzeit time,
Flugdatum date,
FlugzeugName varchar(100),
FHkuerzelZiel char(3),
FHkuerzelStart char(3),
primary key (FlugNr),
foreign key (FlugzeugName) references Flugzeug (FlugzeugName),
foreign key (FHkuerzelZiel) references Flughafen(FHkuerzel),
foreign key (FHkuerzelStart) references Flughafen(FHkuerzel));

create table PilotenFlug
(PersonalNummer varchar(5),
FlugNr varchar(6),
primary key (PersonalNummer,FlugNr),
foreign key (FlugNr) references Flug(FlugNr),
foreign key (PersonalNummer) references Pilot(PersonalNummer));

insert into Flughafen values ('SXF','Berlin-Schönefeld');
insert into Flughafen values ('DRS','Dresden');
insert into Flughafen values ('FRA','Frankfurt/Main');
insert into Flughafen values ('SCN','Saarbrücken');

insert into FlugzeugTyp values ('Airbus A319',150);
insert into FlugzeugTyp values ('Airbus A320',174);
-- insert into FlugzeugTyp values ('Airbus A380',853)
insert into FlugzeugTyp values ('Airbus A380',250);
insert into FlugzeugTyp values ('Bombardier CRJ900',90);

insert into Pilot values ('P0010','Bird','Xaver');
insert into Pilot values ('P0230','Angel','Lydia');
insert into Pilot values ('P0175','Wing','Paul');
insert into Pilot values ('P0051','Cloud','Bernd');
insert into Pilot values ('P0092','Rosin','Kathrin E.');

insert into Pilot values ('P0501','Enzin','Bernd');
insert into Pilot values ('P0502','Black','Irene');
 	
insert into Typberechtigung values ('P0010','Airbus A319'), ('P0010','Airbus A320');
insert into Typberechtigung values ('P0230','Bombardier CRJ900');
insert into Typberechtigung values ('P0175','Airbus A319'),('P0175','Airbus A320'),('P0175','Bombardier CRJ900');
insert into Typberechtigung values ('P0051','Airbus A319'), ('P0051','Airbus A320');
insert into Typberechtigung values ('P0092','Airbus A319'),('P0092','Airbus A320'),('P0092','Bombardier CRJ900');

insert into Flugzeug values
	('Fritz','Airbus A319'),('Wilhelm','Airbus A319'),
	('Claire','Airbus A319'),('Bärbel','Airbus A320'),('Susi','Airbus A320'),
	('Henry','Bombardier CRJ900'),('Anke','Bombardier CRJ900'),('Gerhard','Bombardier CRJ900');

insert into Flug values
('FG0100','08:10','09:30','2014-02-03','Bärbel','SXF','DRS'),
('FG0234','11:35','13:45','2014-02-05','Claire','DRS','FRA'),
('FG0235','09:15','12:30','2014-02-05','Gerhard','SCN','DRS'),
('FG0348','13:30','15:45','2014-02-06','Wilhelm','FRA','SXF'),
('FG0367','13:45','15:00','2014-02-15','Anke','FRA','DRS'),
('FG0390','07:20','10:45','2014-02-08','Claire','SCN','SXF'),
('FG0414','21:40','0:15','2014-02-08','Susi','DRS','SCN');

insert into PilotenFlug (FlugNr,PersonalNummer) values
('FG0100','P0010'),('FG0100','P0175'),
('FG0234','P0092'),('FG0234','P0010'),
('FG0235','P0230'),('FG0235','P0175'),
('FG0348','P0010'),('FG0348','P0051'),
('FG0367','P0230'),('FG0367','P0175'),
('FG0390','P0092'),('FG0390','P0051'),
('FG0414','P0010'),('FG0414','P0175');



/*
4.	Erstellen Sie eine SQL-Anweisung zum Anzeigen einer Liste der Flüge mit Ausgabe der Städtenamen der Start- und 
Zielflüghäfen, den Namen der Piloten, dem Namen, der Typbezeichnung und der Sitzanzahl des jeweils eingesetzten Flugzeugs.
*/

select
	Flug.FlugNr,
	Flug.FHkuerzelStart 'Start-Flughafen',
	Start.Stadt,
	Flug.FHkuerzelZiel 'Ziel-Flughafen',
	Ziel.Stadt,
	Flug.Abflugzeit ,
	Flug.Ankunftzeit,
	Flugzeug.FlugzeugName,
	Flugzeug.Typbezeichnung,
	FlugzeugTyp.Sitzanzahl "Anzahl der Sitze",
	PilotenFlug.PersonalNummer,
	Pilot.Name 'Piloten'
from
	Flug 
		JOIN Flughafen Start ON Flug.FHkuerzelStart = Start.FHkuerzel
		JOIN Flughafen Ziel ON Flug.FHkuerzelZiel = Ziel.FHkuerzel
		JOIN Flugzeug ON Flugzeug.FlugzeugName = Flug.FlugzeugName
		JOIN FlugzeugTyp ON FlugzeugTyp.Typbezeichnung = Flugzeug.Typbezeichnung
		JOIN PilotenFlug ON PilotenFlug.FlugNr = Flug.FlugNr
		JOIN Pilot ON Pilot.PersonalNummer = PilotenFlug.PersonalNummer
order by Flug.FlugNr;

/*
5.	Erstellen Sie eine SQL-Anweisung für eine Liste mit den Namen aller Piloten, die noch nicht für Flüge eingesetzt wurden.
*/

select
PilotenFlug.FlugNr,
PilotenFlug.PersonalNummer,
Pilot.Name
from
PilotenFlug INNER JOIN Pilot ON PilotenFlug.PersonalNummer = Pilot.PersonalNummer;

select
PilotenFlug.FlugNr,
PilotenFlug.PersonalNummer,
Pilot.Name
from PilotenFlug RIGHT OUTER JOIN Pilot ON PilotenFlug.PersonalNummer = Pilot.PersonalNummer
WHERE FlugNr IS NULL;


/*
6.	Erstellen Sie eine SQL-Anweisung für eine Liste mit den Namen der Piloten und den Typbezeichnungen die 
anzeigt, welcher Pilot für welche Flugzeugtypen eine Berechtigung hat.
*/

select
	Typberechtigung.Personalnummer,
	Pilot.Name,
	Typberechtigung.Typbezeichnung
from
	Typberechtigung 
		INNER JOIN Pilot ON Typberechtigung.Personalnummer = Pilot.PersonalNummer;

/* select
	Pilot.Personalnummer,
	Pilot.Name,
	FlugzeugTyp.Typbezeichnung
from
	Typberechtigung 
		FULL OUTER JOIN Pilot ON Typberechtigung.Personalnummer = Pilot.PersonalNummer
		FULL OUTER JOIN FlugzeugTyp on Typberechtigung.Typbezeichnung = FlugzeugTyp.Typbezeichnung;
-- MySQL kennt keinen FULL OUTER JOIN
*/

