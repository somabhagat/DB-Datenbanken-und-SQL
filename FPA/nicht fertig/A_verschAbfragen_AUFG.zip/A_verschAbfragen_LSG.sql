
-- ------------------------------------------------------------------

use edvhandel;
select * from KUNDE;
select * from MWSTSATZ;
select * from ARTIKEL;
select * from HERSTELLER;
select * from POSTEN;
select * from BESTELLUNG;


-- Lösen Sie jede der 4 Aufgaben jeweils in 3 Varianten: 
-- (1) Abfrage über mehrere Tabellen mit JOIN
-- (2) Abfrage über mehrere Tabellen OHNE JOIN
-- (3) Abfrage über mehrere Tabellen mit subselect

/*
Aufgabe 1
Liste mit allen Informationen zu den Artikeln des Herstellers "Matrox". Die Liste soll mit einer SQL-Anweisung erzeugt werden. Die Herstellernummer ist nicht bekannt.
*/

-- Variante 1
select
	artikel.*
from artikel join hersteller on ARTIKEL.HERSTELLER_NR = HERSTELLER.HERSTELLER_NR
where HERSTELLER.NAME = 'Matrox';

-- Variante 2
select
	artikel.*
from artikel, hersteller
where HERSTELLER.NAME = 'Matrox'
		and ARTIKEL.HERSTELLER_NR = HERSTELLER.HERSTELLER_NR;

-- Variante 3
select
	*
from ARTIKEL
where HERSTELLER_NR in (select HERSTELLER_NR from HERSTELLER where NAME = 'Matrox');


/*
Aufgabe 2
Liste aller Posten, in denen der Artikel 'DeskJet 3520' enthalten ist
*/

-- Variante 1
select
	p.*
from ARTIKEL a
		join POSTEN p on a.ARTIKEL_NR = p.ARTIKEL_NR
where a.BEZEICHNUNG = 'DeskJet 3520';

-- Variante 2
select
	p.*
from ARTIKEL a, POSTEN p
where a.BEZEICHNUNG = 'DeskJet 3520'
		and a.ARTIKEL_NR = p.ARTIKEL_NR;

-- VARIANTE subselect
select
	*
from posten
where ARTIKEL_NR IN (select ARTIKEL_NR from ARTIKEL where BEZEICHNUNG = 'DeskJet 3520');


/*
Aufgabe 3
Liste aller Artikel vom Hersteller 'HP' mit einem Nettopreis von 100,00 bis 500,00 aufsteigend sortiert nach Nettopreis
*/

-- Variante 1
select
	a.*
from ARTIKEL a
	join HERSTELLER h on a.HERSTELLER_NR = h.HERSTELLER_NR
where h.NAME = 'HP'
	and a.NETTOPREIS >= 50 
	and a.NETTOPREIS <= 560
order by NETTOPREIS asc;

-- Variante 2
select
	a.*
from ARTIKEL a, HERSTELLER h 
where h.NAME = 'HP'
		and a.NETTOPREIS >= 50 
		and a.NETTOPREIS <= 560
		and a.HERSTELLER_NR = h.HERSTELLER_NR
order by NETTOPREIS asc;

-- Variante 3
select
	*
from ARTIKEL a
where 
	a.HERSTELLER_NR = (select HERSTELLER_NR from HERSTELLER where NAME = 'HP')
		and a.NETTOPREIS >= 50 
		and a.NETTOPREIS <= 560
order by NETTOPREIS asc;


/*
Aufgabe 4
Liste mit Bestell-Nummern der Bestellungen aller Kunden, die den Namen 'Stein' oder 'Lederer' haben
*/
-- Variante 1
select
	BESTELL_NR
from BESTELLUNG b
		join KUNDE k on b.KUNDEN_NR = k.KUNDEN_NR
where k.NAME = 'Stein' or k.NAME = 'Lederer';

-- Variante 2
select
	BESTELL_NR
from BESTELLUNG b, KUNDE k
where b.KUNDEN_NR = k.KUNDEN_NR
		and (k.NAME = 'Stein'
		or k.NAME = 'Lederer');

-- Variante 3
select
	BESTELL_NR
from BESTELLUNG b
where KUNDEN_NR IN ((select KUNDEN_NR from KUNDE where NAME = 'Stein'), (select KUNDEN_NR from KUNDE where NAME = 'Lederer'))

-- ------------------------------------------------------------------


