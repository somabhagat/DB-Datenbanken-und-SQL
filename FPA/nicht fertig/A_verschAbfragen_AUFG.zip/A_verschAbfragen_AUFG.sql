-- ----------------------------------------------------------------------------
-- Verschiedene Abfragen über mehrere Tabellen
-- (1) Verwenden Sie die Datenbank edvhandel_???
-- (2) Beachten Sie, dass jede Aufgabe in 3 Varianten gelöst werden soll.
-- ----------------------------------------------------------------------------

use edvhandel;

select * from KUNDE;
select * from MWSTSATZ;
select * from ARTIKEL;
select * from HERSTELLER;
select * from POSTEN;
select * from BESTELLUNG;


-- Lösen Sie jede der 4 Aufgaben jeweils in 3 Varianten: 
-- (1) Abfrage über mehrere Tabellen mit JOIN
-- (2) Abfrage über mehrere Tabellen OHNE JOIN
-- (3) Abfrage über mehrere Tabellen mit subselect

/*
Aufgabe 1
Liste mit allen Informationen zu den Artikeln des Herstellers "Matrox". Die Liste soll mit einer SQL-Anweisung erzeugt werden. Die Herstellernummer ist nicht bekannt.
*/

-- Variante 1


-- Variante 2


-- Variante 3



/*
Aufgabe 2
Liste aller Posten, in denen der Artikel 'DeskJet 3520' enthalten ist
*/

-- Variante 1



-- Variante 2



-- VARIANTE 3



/*
Aufgabe 3
Liste aller Artikel vom Hersteller 'HP' mit einem Nettopreis von 100,00 bis 500,00 aufsteigend sortiert nach Nettopreis
*/

-- Variante 1



-- Variante 2



-- Variante 3



/*
Aufgabe 4
Liste mit Bestell-Nummern der Bestellungen aller Kunden, die den Namen 'Stein' oder 'Lederer' haben
*/
-- Variante 1



-- Variante 2



-- Variante 3




